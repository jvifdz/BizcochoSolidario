package com.example.demo;

import java.util.Scanner;

import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@SpringBootApplication
@RestController //Indica que el c�digo describe un punto final que
				//deberán estar disponible por la web
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}	
	

	//This tells Spring to use our hello() method to answer requests 
	//that get sent to the http://localhost:8080/hello address.
	//@RequestParam tells Spring to expect a 'name' value in the request,
	//but if it�s not there, it will use the world "World" by default(defaultValue = "World")
	@GetMapping("/hello")
	public String Hello(@RequestParam(value= "name", defaultValue = "World") String name)
	{        	
			
		String nom = "Alejandro";
        return String.format("Hello %s!", nom);
        
	}			
	
	@GetMapping("/pagina")
	public String pagina() {
		String nombrePagina = "Nombre pagina 1";
		return nombrePagina;
	}


}
