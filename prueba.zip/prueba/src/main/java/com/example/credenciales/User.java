package com.example.credenciales;

public class User {
	
	//Atributos del usuario	
	private int id;
	private String nombre;
	private String clave;

}
